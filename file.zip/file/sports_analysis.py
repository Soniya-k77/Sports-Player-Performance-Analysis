import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("player_performance.csv")
df["Contribution"] = df["Runs_Scored"] + df["Goals_Scored"] + df["Assists"]

print(df.nlargest(10, "Performance_Rating")[["Player_Name", "Team", "Performance_Rating"]])
print(df.groupby("Team")["Performance_Rating"].mean())
print(np.mean(df["Performance_Rating"]))
print(df.nlargest(10, "Contribution")[["Player_Name", "Team", "Contribution"]])
print(df["Matches_Played"].corr(df["Performance_Rating"]))

top = df.nlargest(10, "Performance_Rating")
plt.figure(1)
plt.bar(top["Player_Name"], top["Performance_Rating"])
plt.xticks(rotation=45, ha="right")
plt.title("Top Players by Performance Rating")
plt.tight_layout()

plt.figure(2)
plt.scatter(df["Matches_Played"], df["Performance_Rating"])
plt.xlabel("Matches Played")
plt.ylabel("Performance Rating")
plt.title("Matches Played vs Performance Rating")

df.boxplot(column="Performance_Rating", by="Team", rot=45)
plt.suptitle("")
plt.title("Player Ratings by Team")
plt.tight_layout()

plt.figure(4)
plt.hist(df[df["Runs_Scored"] > 0]["Runs_Scored"], bins=20)
plt.xlabel("Runs Scored")
plt.ylabel("Players")
plt.title("Distribution of Runs Scored")

corr = df[["Matches_Played", "Runs_Scored", "Goals_Scored", "Assists", "Wins", "Performance_Rating"]].corr()
plt.figure(5)
plt.imshow(corr, cmap="coolwarm")
plt.colorbar()
plt.xticks(range(len(corr)), corr.columns, rotation=45, ha="right")
plt.yticks(range(len(corr)), corr.columns)
plt.title("Correlation Between Player Statistics")
plt.tight_layout()

plt.show()
